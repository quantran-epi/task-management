export const MIN_WITHDRAW = 1_000_000;
export const MIN_REMAINING = 500_000;

export function isWithdrawalAllowed(principalAmount: number, amount: number): boolean {
  return amount >= MIN_WITHDRAW && principalAmount - amount >= MIN_REMAINING;
}
